package nikev.group.project.chargingplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChargingplatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChargingplatformApplication.class, args);
	}

}
